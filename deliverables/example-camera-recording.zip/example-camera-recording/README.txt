Example RGBD camera recording

Scene 01, seed 18. The robot navigates toward bathroom.
The original recorder output is in session_20261025_132941_7d302745/.
Open rgb.mp4 for the RGB video. RGB JPEGs and lossless depth arrays are also retained.
Each frames.jsonl row pairs RGB and depth filenames with original capture time,
sequence number, camera header, capture pose, and host receive time. Paths are
relative to the session folder. state.jsonl contains the received robot states.

Capture t is simulation time in seconds since the last scene load or reset.
received_ns is host monotonic time in nanoseconds, not Unix wall-clock time.
The MP4 uses fixed 15 fps. Use frames.jsonl for actual timing and capture gaps.

Load a depth file with numpy.load(path, allow_pickle=False)["depth"].
Zero means invalid or out of range. Multiply by metadata.camera.depth_scale
from manifest.json to obtain metres. Depth is optical-axis z-depth.
Camera intrinsics and T_base_camera are in manifest.json under metadata.camera.
T_base_camera maps camera coordinates into robot coordinates. Capture pose
gives robot x, y in metres and yaw in radians in the world frame.

